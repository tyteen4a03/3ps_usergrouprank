<?php
/*
* Usergroup Ranks v1.5.6 written by tyteen4a03@3.studIo.
* This software is licensed under the BSD 2-Clause modified License.
* See the LICENSE file within the package for details.
*/

class ThreePointStudio_UsergroupRanks_Model_DataRegistry extends XFCP_ThreePointStudio_UsergroupRanks_Model_DataRegistry {

}